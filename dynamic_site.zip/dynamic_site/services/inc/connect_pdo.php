<?php

$user = "sekhrilovish";
$pass = "BNytMSdk";

$dbo = new PDO('mysql:host=localhost;dbname=sekhrilovish', $user, $pass);

?>
